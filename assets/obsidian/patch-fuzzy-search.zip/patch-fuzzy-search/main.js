// not even bothering with a build environment for this garbage
// also who even uses `var` anymore

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
    for (var name in all) __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
    if ((from && typeof from === "object") || typeof from === "function") {
        for (let key of __getOwnPropNames(from))
            if (!__hasOwnProp.call(to, key) && key !== except)
                __defProp(to, key, {
                    get: () => from[key],
                    enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable,
                });
    }
    return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

var main_exports = {};
__export(main_exports, {
    default: () => PatchFuzzySearch,
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");

const originalFunctions = {};

var PatchFuzzySearch = class extends import_obsidian.Plugin {
    async onload() {
        new import_obsidian.Notice("Patching fuzzy search...");

        this.patchUndos = [];

        function sample(arr, count = 9999) {
            const limit = Math.min(count, arr.length);
            const picked = new Set();
            while (picked.size < limit) {
                picked.add(Math.floor(arr.length * Math.random()));
            }
            return [...picked].sort((a, b) => a - b).map((i) => arr[i]);
        }

        const vProto = this.app.vault.__proto__;
        vProto.getFilesOriginal = vProto.getFiles;
        vProto.getFiles = function (...args) {
            const files = this.getFilesOriginal(...args);

            if (files.length > 9999) {
                // getFiles is used a lot so we don't want to mess with it entirely
                // but i *think* .filter is only used for the file switcher
                files.filter = function (...args) {
                    return sample(files, 9999).filter(...args);
                };
            }

            return files;
        };
        this.patchUndos.push(() => {
            vProto.getFiles = vProto.getFilesOriginal;
            delete vProto.getFilesOriginal;
        });

        const mdProto = this.app.metadataCache.__proto__;
        mdProto.getLinkSuggestionsOriginal = mdProto.getLinkSuggestions;
        mdProto.getLinkSuggestions = function (...args) {
            const suggestions = this.getLinkSuggestionsOriginal(...args);
            if (suggestions.length > 9999) {
                const array = sample(suggestions);
                let lastShuffled = 0;
                const proxy = new Proxy(array, {
                    get(target, prop, receiver) {
                        // this is just awful
                        // absolutely evil
                        // but it works :)
                        if (lastShuffled + 1000 < Date.now()) {
                            lastShuffled = Date.now();
                            array.length = 0;
                            array.push(...sample(suggestions));
                        }

                        return Reflect.get(target, prop, receiver);
                    },
                });
                return proxy;
            } else {
                return suggestions;
            }
        };
        this.patchUndos.push(() => {
            mdProto.getLinkSuggestions = mdProto.getLinkSuggestionsOriginal;
            delete mdProto.getLinkSuggestionsOriginal;
        });

        // i tried so hard
        // and i got so far
        // but in the end it doesn't even matter
        // because i can patch the function but can't keep the captured variables

        // const commandPalette = this.app.setting.pluginTabs.find((tab) => tab.id === "command-palette");
        // {
        //     const proto = commandPalette.instance.modal;
        //     const fn = proto.getSuggestions;
        //     console.log(fn.toString());
        //     // const proto = suggests[0].__proto__;
        //     // const name = "getSuggestions";
        //     // const fnText = proto[name]?.toString();
        //     // console.log(fnText);
        // }
        // const suggests = this.app.workspace.editorSuggest.suggests;
        // {
        //     const proto = suggests[0].suggestManager.__proto__;
        //     const fnOriginal = proto.getFileSuggestions;
        //     const fnText = fnOriginal.toString();
        //     const fnPatched = fnText.replace("1e4", "1e7");
        //     const newFn = new Function("return " + fnPatched)();
        //     // proto.getFileSuggestions = newFn;
        //     this.patchUndos.push(() => {
        //         // proto.getFileSuggestions = fnOriginal;
        //     });
        // }
        // this.proto = this.app.workspace.editorSuggest.suggests[0].suggestManager.__proto__;
        // this.originalFunctions = {};
        // for (const name of ["getSuggestions", "getFileSuggestions"]) {
        //     const functionText = this.proto[name]?.toString();
        //     console.log(functionText);
        // }
        // console.log(this.app.workspace.editorSuggest.suggests[0].suggestManager.__proto__);
    }
    onunload() {
        for (const undo of this.patchUndos) {
            try {
                undo();
            } catch (e) {
                new import_obsidian.Notice(`Failed to undo patch: ${e.message}\nYou probably want to reload Obsidian.`);
                console.error("Failed to undo patch:", e);
            }
        }
    }
};
